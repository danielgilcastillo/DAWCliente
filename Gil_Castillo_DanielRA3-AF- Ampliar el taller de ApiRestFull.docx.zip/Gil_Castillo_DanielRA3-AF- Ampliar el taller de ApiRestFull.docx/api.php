
<?php
header('Content-Type: application/json');

$usuarios = [
    ["id" => 1, "nombre" => "Juan", "apellidos" => "Pérez", "direccion" => "Calle A"],
    ["id" => 2, "nombre" => "Ana", "apellidos" => "García", "direccion" => "Calle B"],
    ["id" => 3, "nombre" => "Luis", "apellidos" => "Martínez", "direccion" => "Calle C"],
];

$clientes = [
    ["id" => 1, "nombre" => "Empresa A", "direccion" => "Calle X", "ciudad" => "Ciudad 1", "telefono" => "123456"],
    ["id" => 2, "nombre" => "Empresa B", "direccion" => "Calle Y", "ciudad" => "Ciudad 2", "telefono" => "789012"],
    ["id" => 3, "nombre" => "Empresa C", "direccion" => "Calle Z", "ciudad" => "Ciudad 3", "telefono" => "345678"],
];

session_start();

/**
 * Processes HTTP requests for user and client operations.
 * Supports login, add user, add client, delete user, and delete client.
 */
switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        if (isset($_GET['action']) && $_GET['action'] == 'login') {
            $contenido = file_get_contents('php://input');
            $datos = json_decode($contenido, true);

            if ($datos['username'] === 'admin' && $datos['password'] === '1234') {
                $_SESSION['loggedin'] = true;
                echo json_encode(["mensaje" => "Login exitoso"]);
            } else {
                http_response_code(401);
                echo json_encode(["error" => "Credenciales incorrectas"]);
            }
        }
        elseif (isset($_GET['action']) && $_GET['action'] == 'add') {
            $contenido = file_get_contents('php://input');
            $datos = json_decode($contenido, true);
            $nuevoUsuario = [
                "id" => count($usuarios) + 1,
                "nombre" => $datos['nombre'],
                "apellidos" => $datos['apellidos'],
                "direccion" => $datos['direccion']
            ];
            $usuarios[] = $nuevoUsuario;
            echo json_encode(["mensaje" => "Usuario agregado con éxito", "usuario" => $nuevoUsuario]);
        }
        elseif (isset($_GET['action']) && $_GET['action'] == 'addClient') {
            $contenido = file_get_contents('php://input');
            $datos = json_decode($contenido, true);
            $nuevoCliente = [
                "id" => count($clientes) + 1,
                "nombre" => $datos['nombre'],
                "direccion" => $datos['direccion'],
                "ciudad" => $datos['ciudad'],
                "telefono" => $datos['telefono']
            ];
            $clientes[] = $nuevoCliente;
            echo json_encode(["mensaje" => "Cliente agregado con éxito", "cliente" => $nuevoCliente]);
        }
        break;

    case 'GET':
        if (isset($_GET['action']) && $_GET['action'] == 'fetchClients') {
            echo json_encode($clientes);
        } elseif (isset($_SESSION['loggedin']) && $_SESSION['loggedin']) {
            echo json_encode($usuarios);
        } else {
            http_response_code(401);
            echo json_encode(["error" => "No autorizado"]);
        }
        break;

    case 'DELETE':
        parse_str(file_get_contents("php://input"), $datos);
        if (isset($_GET['action']) && $_GET['action'] == 'deleteClient') {
            $id = $datos['id'];
            $index = array_search($id, array_column($clientes, 'id'));
            if ($index !== false) {
                array_splice($clientes, $index, 1);
                echo json_encode(["mensaje" => "Cliente eliminado con éxito"]);
            } else {
                http_response_code(404);
                echo json_encode(["error" => "Cliente no encontrado"]);
            }
        } else {
            $id = $datos['id'];
            $index = array_search($id, array_column($usuarios, 'id'));
            if ($index !== false) {
                array_splice($usuarios, $index, 1);
                echo json_encode(["mensaje" => "Usuario eliminado con éxito"]);
            } else {
                http_response_code(404);
                echo json_encode(["error" => "Usuario no encontrado"]);
            }
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Método no soportado"]);
        break;
}
?>